export { enableDraftHandler as GET } from "@contentful/vercel-nextjs-toolkit/app-router"
